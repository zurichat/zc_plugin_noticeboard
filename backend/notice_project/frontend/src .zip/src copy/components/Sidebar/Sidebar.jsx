import React from 'react'
import "./Sidebar.css"

function Sidebar() {
    return (
        <div className="sidebar">
            
        </div>
    )
}

export default Sidebar
