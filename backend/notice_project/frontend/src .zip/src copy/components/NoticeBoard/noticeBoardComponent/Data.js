// export default {
const user = [
  {
    id: 1,
    userImage:
      "https://images.unsplash.com/photo-1582233479366-6d38bc390a08?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8ZmFjZXN8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
    userName: "Tiwa Suleiman",
    date: "17 days ago",
    timeStamp: "6 Hours ago",
    views: "321",
    title: "Meet up at the hall of Justice",
    info: "All Justice League members are hereby summoned! ...the original members of the Justice League have formed a new sub-team called the Titans, and a proper ceremony will be held today at the Hall of Justice... More information will be supplied as soon as possible",
    attachedImage: null,
  },
  {
    id: 2,
    userImage:
      "https://images.unsplash.com/photo-1512849934327-1cf5bf8a5ccc?ixid=MnwxMjA3fDB8MHxzZWFyY2h8OHx8ZmFjZXN8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
    userName: "Bessie Cooper",
    date: "17 days ago",
    timeStamp: "6 Hours ago",
    views: "212",
    title: "Meet up at the hall of Justice",
    info: "All Justice League members are hereby summoned! ...the original members of the Justice League have formed a new sub-team called the Titans, and a proper ceremony will be held today at the Hall of Justice... More information will be supplied as soon as possible",
    attachedImage: null,
  },
  {
    id: 3,
    userImage:
      "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTR8fGZhY2VzfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
    userName: "Berry Allen",
    date: "17 days ago",
    timeStamp: "6 Hours ago",
    views: "403",
    title: "Meet up at the hall of Justice",
    info: "All Justice League members are hereby summoned! ...the original members of the Justice League have formed a new sub-team called the Titans, and a proper ceremony will be held today at the Hall of Justice... More information will be supplied as soon as possible",
    attachedImage: null,
  },
  {
    id: 4,
    userImage:
      "https://images.unsplash.com/photo-1546456073-92b9f0a8d413?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MjN8fGZhY2VzfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
    userName: "Arlene McCoy",
    date: "17 days ago",
    timeStamp: "6 Hours ago",
    views: "21",
    title: "Meet up at the hall of Justice",
    info: "All Justice League members are hereby summoned! ...the original members of the Justice League have formed a new sub-team called the Titans, and a proper ceremony will be held today at the Hall of Justice... More information will be supplied as soon as possible",
    attachedImage: null,
  },
  {
    id: 5,
    userImage:
      "https://images.unsplash.com/photo-1606459431839-90b942dc3754?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MzJ8fGZhY2VzfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
    userName: "Robert Fox",
    date: "17 days ago",
    timeStamp: "6 Hours ago",
    views: "32",
    title: "Meet up at the hall of Justice",
    info: "All Justice League members are hereby summoned! ...the original members of the Justice League have formed a new sub-team called the Titans, and a proper ceremony will be held today at the Hall of Justice... More information will be supplied as soon as possible",
    attachedImage: null,
  },
  {
    id: 6,
    userImage:
      "https://images.unsplash.com/photo-1569243478735-8fcf29052262?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MzN8fGZhY2VzfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
    userName: "Leslie Alexander",
    date: "17 days ago",
    timeStamp: "6 Hours ago",
    views: "1",
    title: "Meet up at the hall of Justice",
    info: "All Justice League members are hereby summoned! ...the original members of the Justice League have formed a new sub-team called the Titans, and a proper ceremony will be held today at the Hall of Justice... More information will be supplied as soon as possible",
    attachedImage: null,
  },
];
// }

export default user;
