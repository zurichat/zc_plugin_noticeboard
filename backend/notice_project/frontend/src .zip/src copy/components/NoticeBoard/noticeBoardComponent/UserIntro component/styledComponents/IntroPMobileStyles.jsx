import styled from "styled-components";

export const IntroPMobileStyles = styled.div`
  display: block;
  font-family: Lato;
  font-style: normal;
  font-weight: normal;
  text-align: center;
  color: #333333;
  margin-bottom: 24px;
`;
